"""Core module for tree interval package."""
