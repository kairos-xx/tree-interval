
"""Main entry point for examples package."""
from . import run_demos

if __name__ == "__main__":
    run_demos()
