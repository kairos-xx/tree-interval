
# Installation

Tree Interval can be installed using pip:

```bash
pip install tree-interval
```

## Requirements
- Python >= 3.11
